import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';

class App extends Component {
  render() {
    return (
      <div className="App">
        <header className="App-header">
          <img src={logo} className="App-logo" alt="logo" />
          <h1 className="App-title">亲爱的王百智</h1>
        </header>
        <p className="App-intro">
        <h1>欢迎来到react召唤师峡谷</h1><code>敌军还有100秒到达战场，请做好准备</code>
        </p>
      </div>
    );
  }
}

export default App;
